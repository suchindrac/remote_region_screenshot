using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Runtime.InteropServices;

namespace RegionVNCClient
{
   	public partial class RegionVNCClient : Form
        {

		int screen_width = SystemInformation.VirtualScreen.Width;
		int screen_height = SystemInformation.VirtualScreen.Height;
        
		String command;
		String ipAddress;
		int portNumber;
		PictureBox imageControl;
		
		[DllImport("kernel32.dll")]
 		 [return: MarshalAs(UnmanagedType.Bool)]
 		 static extern bool AllocConsole();
 		[System.Runtime.InteropServices.DllImport("user32.dll")]
		 private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);
		 
		[System.Runtime.InteropServices.DllImport("user32.dll")]
		 private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

		Dictionary<string, dynamic> image_types = new Dictionary<string, dynamic>();
		
		enum KeyModifier
		{
			None = 0,
			Alt = 1,
			Control = 2,
			Shift = 4,
			WinKey = 8
		}

		private string sendMessage(string ip, int port, string cmd)
		{
			TcpClient client = new TcpClient();

			IPEndPoint serverEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);

			client.Connect(serverEndPoint);

			NetworkStream clientStream = client.GetStream();

			ASCIIEncoding encoder = new ASCIIEncoding();
			byte[] buffer = encoder.GetBytes(cmd);

			clientStream.Write(buffer, 0 , buffer.Length);
			clientStream.Flush();
			byte[] message = new byte[40960];
			int bytesRead = clientStream.Read(message, 0, 40960);

			clientStream.Flush();
			Image image;
			using (MemoryStream ms = new MemoryStream(message))
			{
				image = Image.FromStream(ms);
			}

			image.Save("test_rec.png", ImageFormat.Png);

			this.Size = new Size(image.Width, image.Height);
			
			this.imageControl = new PictureBox();  
			this.imageControl.Width = image.Width;  
			this.imageControl.Height = image.Height;  
			this.imageControl.SizeMode = PictureBoxSizeMode.StretchImage;
			this.imageControl.BorderStyle = BorderStyle.None;
			this.imageControl.Image = image;
			this.Controls.Add(imageControl);  

			this.Show();
			
			return "string";
		}

		public RegionVNCClient(String command, String ipAddress, int portNumber)
		{
			this.command = command;
			this.ipAddress = ipAddress;
			this.portNumber = portNumber;
			
			InitializeComponent();
		
			

			sendMessage(this.ipAddress, this.portNumber, this.command);
		}
		
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
		       	switch(keyData)
		       	{
				case Keys.Escape:
					this.Close();
					Application.Exit();
					break;

			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		#region Windows Form Designer generated code
		
		private void InitializeComponent()
		{
			this.Bounds = Screen.PrimaryScreen.Bounds;
			this.TopMost = true;
			this.FormBorderStyle = FormBorderStyle.None;
			this.Opacity = 1;
			this.Name = "RegionVNC Client";
			this.Text = "RegionVNC Client";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		
		#endregion
		
		[STAThread]
		static void Main(String[] args)
		{
			string command = string.Join(" ", args.Skip(2).Take(5).ToArray());
			string ipAddress = args[0];
			int portNumber = Convert.ToInt32(args[1]);

			if (args.Length == 0)
			{
				MessageBox.Show("Invalid command, Try display 100 200 300 400");
				Application.Exit();
			}

			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			
			try
			{
				Application.Run(new RegionVNCClient(command, ipAddress, portNumber));
			}
			catch
			{
			}
					
		}
        }
}