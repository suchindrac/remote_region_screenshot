using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Runtime.InteropServices;

namespace RegionVNC
{
    /*
     * Create a class which is a Child of Form
     * 
     */
    public partial class Form1 : Form, IMessageFilter
    {
    
    	private TcpListener tcpListener;
    	private Thread listenThread;
    	
        int screen_width = SystemInformation.VirtualScreen.Width;
	int screen_height = SystemInformation.VirtualScreen.Height;
	
	int x1 = 0;
	int y1 = 0;
	int x2 = 0;
	int y2 = 0;
	
	[DllImport("user32.dll")]
	private static extern bool SetForegroundWindow(IntPtr hWnd);
	
	[System.Runtime.InteropServices.DllImport("user32.dll")]
	private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);
	
	[System.Runtime.InteropServices.DllImport("user32.dll")]
	private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

	[DllImport("user32.dll", SetLastError = true)]
	static extern IntPtr SetFocus(IntPtr hWnd);

	[DllImport("user32.dll")]
	[return:MarshalAs(UnmanagedType.Bool)]
	public static extern bool InvertRect(IntPtr hDC, ref System.Drawing.Rectangle lprc);
	
	
       	enum KeyModifier
	{
	        None = 0,
	        Alt = 1,
		Control = 2,
		Shift = 4,
		WinKey = 8
	}
	
	public bool PreFilterMessage(ref Message m)
	{
		const int WM_KEYUP = 0x101;
		if (m.Msg == WM_KEYUP)
   		{
   			return true;
   		} else {
   			return false;
   		}
   		
   	}
        
        public Form1()
        {
        	Application.AddMessageFilter(this);
        	
		this.FormBorderStyle = FormBorderStyle.None;
            	/*
             	* Initialize component
             	* 
             	*/
            	InitializeComponent();

            	/*
            	 * Form background, border and transparency
            	 * 
            	 */
            	this.Bounds = Screen.PrimaryScreen.Bounds;
            	this.TopMost = true;
            	this.Size = new Size(screen_width, screen_height);
            	this.BackColor = Color.White;
            	this.TransparencyKey  = Color.Black;
		            	    	
            	this.Opacity = 0;
            	this.Show();
            	
            	this.tcpListener = new TcpListener(IPAddress.Any, 567);
            	this.listenThread = new Thread(new ThreadStart(ListenForClients));
            	this.listenThread.Start();
            	
            	
	}
	
	private void ListenForClients()
	{
		this.tcpListener.Start();
		
		while (true)
		{
			TcpClient client = this.tcpListener.AcceptTcpClient();
			
			Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
			clientThread.Start(client);
		}
	}
	
	private void HandleClientComm(object client)
	{
		TcpClient tcpClient  = (TcpClient) client;
		NetworkStream clientStream = tcpClient.GetStream();
		
		byte[] message = new byte[4096];
   		int bytesRead;
   		
		while (true)
		{
			bytesRead = 0;
			try
			{
				bytesRead = clientStream.Read(message, 0, 4096);
				
			}
			catch (Exception e)
			{
				break;
			}
			
			if (bytesRead == 0)
			{
				break;
			}
			
			
			ASCIIEncoding encoder = new ASCIIEncoding();
			
			string clientMsg = encoder.GetString(message, 0, bytesRead);
			byte[] imageBytes = ProcessClientCmd(clientMsg);
			
			// byte[] toSendToClient = Encoding.ASCII.GetBytes(imageString);
			
			clientStream.Write(imageBytes, 0, imageBytes.Length);
			clientStream.Flush();
		}
		tcpClient.Close();
	}
	protected override CreateParams CreateParams
	{
	    get
	    {
		CreateParams createParams = base.CreateParams;
		createParams.ExStyle |= 0x00000020; // WS_EX_TRANSPARENT

		return createParams;
	    }
	}
	
	public byte[] ProcessClientCmd(string msg)
	{
		string[] msgList = msg.Split(null);
		byte[] retn = new byte[1];
		
		switch(msgList[0])
		{
			case "display":
				int x;
				int y;
				int w;
				int h;
				
				if (msgList[3] == "0")
				{
					if (this.x2 != 0)
					{
						x = this.x1;
						y = this.y1;
						w = this.x2 - this.x1;
						h = this.y2 - this.y1;
						this.x1 = 0;
						this.y1 = 0;
						this.x2 = 0;
						this.y2 = 0;
					}
					else
					{
						x = 100;
						y = 100;
						w = 500;
						h = 500;
					}						
				}
				else
				{
					x = Convert.ToInt32(msgList[1]);
					y = Convert.ToInt32(msgList[2]);
					w = Convert.ToInt32(msgList[3]);
					h = Convert.ToInt32(msgList[4]);
				}
				Bitmap image = new Bitmap(w, h, 
				                   System.Drawing.Imaging.PixelFormat.Format32bppArgb);
				Graphics g = Graphics.FromImage(image);
				g.CompositingQuality = CompositingQuality.HighQuality;
				g.InterpolationMode = InterpolationMode.HighQualityBicubic;
				g.SmoothingMode = SmoothingMode.HighQuality;
				g.PixelOffsetMode = PixelOffsetMode.HighQuality;

				g.CopyFromScreen(x, y, 0, 0, 
				                     new System.Drawing.Size(w, h), 
				                     CopyPixelOperation.SourceCopy);

				try
				{
					using (MemoryStream m = new MemoryStream())
					{
						image.Save(m, ImageFormat.Png);
						byte[] imageBytes = m.ToArray();
						return imageBytes;
					}
				}
				catch (Exception e)
				{
					MessageBox.Show(e.ToString());
				}
				break;
		}
		return retn;
	}
	protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
	{
	       	switch(keyData)
	       	{
		   	case Keys.Q:
		   		this.tcpListener.Stop();
		   		this.listenThread.Join();
		   		this.Close();
                		Application.Exit();
                		break;
                	case Keys.A:
                		this.x1 = PointToScreen(Cursor.Position).X;
                		this.y1 = PointToScreen(Cursor.Position).Y;
                		break;
                	case Keys.B:
                		this.x2 = PointToScreen(Cursor.Position).X;
                		this.y2 = PointToScreen(Cursor.Position).Y;
                		break;
		}	
		return base.ProcessCmdKey(ref msg, keyData);
	}

        #region Windows Form Designer generated code
	
	private void InitializeComponent()
	{

            	// 
            	// Form1
            	// 
            	
            	this.AutoSize = false;
            	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            	this.ClientSize = new System.Drawing.Size(screen_width, screen_height);
            	this.Name = "regionVNC Server";
            	this.Text = "regionVNC Server";
            	this.ResumeLayout(false);
           	this.PerformLayout();
	}	
	
	#endregion

	[STAThread]
	static void Main()
	{
������� 	Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);
		Application.Run(new Form1());
	}
    }
}
